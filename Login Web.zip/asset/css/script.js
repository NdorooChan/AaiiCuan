// Konfigurasi
const API_URL = 'https://script.google.com/macros/s/AKfycbxvnGNFUcNPz-8tpXyRWs3CIl0_mDKXP3d6_2XBYXgtsssy4rBu13a1Wi1461BWsaiA/exec'; // Ganti dengan URL Web App Anda

// DOM Elements
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');
const showRegister = document.getElementById('showRegister');
const showLogin = document.getElementById('showLogin');
const container = document.getElementById('container');

// Dashboard Elements
const dashboardUsername = document.getElementById('dashboardUsername');
const userPoints = document.getElementById('userPoints');
const missionsContainer = document.getElementById('missionsContainer');
const logoutBtn = document.getElementById('logoutBtn');
const missionModal = document.getElementById('missionModal');
const missionFrame = document.getElementById('missionFrame');
const missionTitle = document.getElementById('missionTitle');
const countdown = document.getElementById('countdown');
const progressBar = document.getElementById('progressBar');
const closeModal = document.getElementById('closeModal');
const notification = document.getElementById('notification');

// Event Listeners
if (loginForm) {
  loginForm.addEventListener('submit', handleLogin);
}

if (registerForm) {
  registerForm.addEventListener('submit', handleRegister);
}

if (showRegister) {
  showRegister.addEventListener('click', () => {
    container.classList.add('right-panel-active');
  });
}

if (showLogin) {
  showLogin.addEventListener('click', () => {
    container.classList.remove('right-panel-active');
  });
}

if (logoutBtn) {
  logoutBtn.addEventListener('click', handleLogout);
}

if (closeModal) {
  closeModal.addEventListener('click', () => {
    missionModal.style.display = 'none';
    missionFrame.src = '';
  });
}

// Check if user is already logged in
document.addEventListener('DOMContentLoaded', () => {
  if (window.location.pathname.includes('dashboard.html')) {
    const username = sessionStorage.getItem('username');
    if (!username) {
      window.location.href = 'index.html';
    } else {
      loadDashboard(username);
    }
  }
});

// Functions
async function handleLogin(e) {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;
  
  try {
    const response = await fetch(`${API_URL}?action=login&username=${username}&password=${password}`);
    const data = await response.json();
    
    if (data.success) {
      sessionStorage.setItem('username', username);
      window.location.href = 'dashboard.html';
    } else {
      alert(data.message || 'Login failed');
    }
  } catch (error) {
    console.error('Error:', error);
    alert('An error occurred during login');
  }
}

async function handleRegister(e) {
  e.preventDefault();
  const username = document.getElementById('regUsername').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  
  try {
    const response = await fetch(`${API_URL}?action=register&username=${username}&email=${email}&password=${password}`);
    const data = await response.json();
    
    if (data.success) {
      alert('Registration successful! Please login.');
      container.classList.remove('right-panel-active');
      registerForm.reset();
    } else {
      alert(data.message || 'Registration failed');
    }
  } catch (error) {
    console.error('Error:', error);
    alert('An error occurred during registration');
  }
}

function handleLogout() {
  sessionStorage.removeItem('username');
  window.location.href = 'index.html';
}

async function loadDashboard(username) {
  dashboardUsername.textContent = username;
  
  // Load user points
  await updateUserPointsDisplay(username);
  
  // Load missions
  await loadMissions();
}

async function updateUserPointsDisplay(username) {
  try {
    const response = await fetch(`${API_URL}?action=getUserData&username=${username}`);
    const data = await response.json();
    
    if (data.success) {
      userPoints.textContent = data.points;
    }
  } catch (error) {
    console.error('Error updating points:', error);
  }
}

async function loadMissions() {
  try {
    const response = await fetch(`${API_URL}?action=getMissions`);
    const data = await response.json();
    
    if (data.success) {
      missionsContainer.innerHTML = '';
      data.missions.forEach(mission => {
        const missionCard = document.createElement('div');
        missionCard.className = 'mission-card';
        missionCard.innerHTML = `
          <h3>${mission.title}</h3>
          <p>Complete this mission to earn 10 points</p>
          <button class="start-btn" data-id="${mission.id}" data-link="${mission.link}" data-duration="${mission.duration}">Start Mission</button>
        `;
        missionsContainer.appendChild(missionCard);
      });
      
      // Add event listeners to mission buttons
      document.querySelectorAll('.start-btn').forEach(btn => {
        btn.addEventListener('click', startMission);
      });
    }
  } catch (error) {
    console.error('Error loading missions:', error);
  }
}

function startMission(e) {
  const missionId = e.target.getAttribute('data-id');
  const missionLink = e.target.getAttribute('data-link');
  const duration = parseInt(e.target.getAttribute('data-duration'));
  
  missionTitle.textContent = `Mission ${missionId}`;
  missionFrame.src = missionLink;
  missionModal.style.display = 'block';
  
  // Start countdown
  let timeLeft = duration;
  countdown.textContent = timeLeft;
  progressBar.style.width = '100%';
  
  const timer = setInterval(() => {
    timeLeft--;
    countdown.textContent = timeLeft;
    progressBar.style.width = `${(timeLeft / duration) * 100}%`;
    
    if (timeLeft <= 0) {
      clearInterval(timer);
      missionComplete();
    }
  }, 1000);
}

async function missionComplete() {
  // Show notification
  notification.classList.add('show');
  
  // Get current user
  const username = sessionStorage.getItem('username');
  
  try {
    // Get current points
    const response = await fetch(`${API_URL}?action=getUserData&username=${username}`);
    const data = await response.json();
    
    if (data.success) {
      const currentPoints = data.points || 0;
      const newPoints = currentPoints + 10;
      
      // Update points
      await fetch(`${API_URL}?action=updatePoints&username=${username}&points=${newPoints}`);
      
      // Update display
      userPoints.textContent = newPoints;
    }
  } catch (error) {
    console.error('Error updating points:', error);
  }
  
  // Hide notification after 3 seconds
  setTimeout(() => {
    notification.classList.remove('show');
  }, 3000);
  
  // Close modal after 5 seconds
  setTimeout(() => {
    missionModal.style.display = 'none';
    missionFrame.src = '';
  }, 5000);
} 